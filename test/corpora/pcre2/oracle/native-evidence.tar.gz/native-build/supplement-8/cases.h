static const PCRE2_UCHAR p0[]={92,98,97,0};
static const PCRE2_UCHAR s0[]={255,97,0};
static const PCRE2_UCHAR r0[]={0};
static const PCRE2_UCHAR n0[]={110,0};
static const PCRE2_UCHAR p1[]={40,63,60,61,46,41,97,0};
static const PCRE2_UCHAR s1[]={255,97,0};
static const PCRE2_UCHAR r1[]={0};
static const PCRE2_UCHAR n1[]={110,0};
static const PCRE2_UCHAR p2[]={46,0};
static const PCRE2_UCHAR s2[]={255,97,0};
static const PCRE2_UCHAR r2[]={0};
static const PCRE2_UCHAR n2[]={110,0};
static const PCRE2_UCHAR p3[]={40,42,78,79,95,83,84,65,82,84,95,79,80,84,41,40,42,77,65,82,75,58,65,0,66,41,40,63,67,49,41,97,0};
static const PCRE2_UCHAR s3[]={97,0};
static const PCRE2_UCHAR r3[]={0};
static const PCRE2_UCHAR n3[]={110,0};
static const int cr3[]={0};
static const PCRE2_UCHAR p4[]={40,42,78,79,95,83,84,65,82,84,95,79,80,84,41,40,42,77,65,82,75,58,65,0,66,41,40,63,67,49,41,97,0};
static const PCRE2_UCHAR s4[]={98,0};
static const PCRE2_UCHAR r4[]={0};
static const PCRE2_UCHAR n4[]={110,0};
static const int cr4[]={0};
static const PCRE2_UCHAR p5[]={40,42,78,79,95,83,84,65,82,84,95,79,80,84,41,40,42,77,65,82,75,58,65,0,66,41,40,63,67,49,41,97,0};
static const PCRE2_UCHAR s5[]={97,0};
static const PCRE2_UCHAR r5[]={0};
static const PCRE2_UCHAR n5[]={110,0};
static const int cr5[]={-777};
static const PCRE2_UCHAR p6[]={40,63,67,34,0,34,41,97,0};
static const PCRE2_UCHAR s6[]={97,0};
static const PCRE2_UCHAR r6[]={0};
static const PCRE2_UCHAR n6[]={110,0};
static const PCRE2_UCHAR p7[]={40,42,78,79,95,83,84,65,82,84,95,79,80,84,41,40,42,77,65,82,75,58,65,0,66,41,40,63,67,49,41,97,0};
static const PCRE2_UCHAR s7[]={97,0};
static const PCRE2_UCHAR r7[]={0};
static const PCRE2_UCHAR n7[]={110,0};
static const int cr7[]={0};
static const PCRE2_UCHAR p8[]={40,42,78,79,95,83,84,65,82,84,95,79,80,84,41,40,42,77,65,82,75,58,65,0,66,41,40,63,67,49,41,97,0};
static const PCRE2_UCHAR s8[]={98,0};
static const PCRE2_UCHAR r8[]={0};
static const PCRE2_UCHAR n8[]={110,0};
static const int cr8[]={0};
static const PCRE2_UCHAR p9[]={40,42,78,79,95,83,84,65,82,84,95,79,80,84,41,40,42,77,65,82,75,58,65,0,66,41,40,63,67,49,41,97,0};
static const PCRE2_UCHAR s9[]={97,0};
static const PCRE2_UCHAR r9[]={0};
static const PCRE2_UCHAR n9[]={110,0};
static const int cr9[]={-777};
static const PCRE2_UCHAR p10[]={40,63,67,34,0,34,41,97,0};
static const PCRE2_UCHAR s10[]={97,0};
static const PCRE2_UCHAR r10[]={0};
static const PCRE2_UCHAR n10[]={110,0};
static const Case cases[]={
{"utfwindow-988-8",0,p0,s0,r0,n0,3,2,0,524288,0,0,0,2,1,255,8,128,1,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0},
{"utfwindow-990-8",0,p1,s1,r1,n1,7,2,0,524288,0,0,0,2,1,255,8,128,1,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0},
{"utfwindow-992-8",0,p2,s2,r2,n2,1,2,0,524288,0,0,0,2,1,255,8,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0},
{"binary-mark-8-raw-0",0,p3,s3,r3,n3,32,1,0,0,0,0,0,2,1,255,8,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,cr3,NULL,1,SIZE_MAX,NULL,0,-1,NULL,0},
{"binary-mark-8-raw-1",0,p4,s4,r4,n4,32,1,0,0,0,0,0,2,1,255,8,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,cr4,NULL,1,SIZE_MAX,NULL,0,-1,NULL,0},
{"binary-mark-8-raw-2",0,p5,s5,r5,n5,32,1,0,0,0,0,0,2,1,255,8,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,cr5,NULL,1,SIZE_MAX,NULL,0,-1,NULL,0},
{"binary-callout-8-raw",0,p6,s6,r6,n6,8,1,0,0,0,0,0,2,1,255,8,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0},
{"binary-mark-8-utf-4",0,p7,s7,r7,n7,32,1,0,524288,0,0,0,2,1,255,8,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,cr7,NULL,1,SIZE_MAX,NULL,0,-1,NULL,0},
{"binary-mark-8-utf-5",0,p8,s8,r8,n8,32,1,0,524288,0,0,0,2,1,255,8,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,cr8,NULL,1,SIZE_MAX,NULL,0,-1,NULL,0},
{"binary-mark-8-utf-6",0,p9,s9,r9,n9,32,1,0,524288,0,0,0,2,1,255,8,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,cr9,NULL,1,SIZE_MAX,NULL,0,-1,NULL,0},
{"binary-callout-8-utf",0,p10,s10,r10,n10,8,1,0,524288,0,0,0,2,1,255,8,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0}
};
