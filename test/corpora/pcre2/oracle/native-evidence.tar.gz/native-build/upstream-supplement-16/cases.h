static const PCRE2_UCHAR p0[]={40,42,77,65,82,75,58,65,92,120,48,48,98,41,0};
static const PCRE2_UCHAR s0[]={97,98,99,0};
static const PCRE2_UCHAR r0[]={0};
static const PCRE2_UCHAR n0[]={110,0};
static const PCRE2_UCHAR p1[]={40,42,77,65,82,75,58,65,0,98,41,0};
static const PCRE2_UCHAR s1[]={97,98,99,0};
static const PCRE2_UCHAR r1[]={0};
static const PCRE2_UCHAR n1[]={110,0};
static const PCRE2_UCHAR p2[]={40,42,77,65,82,75,58,65,0,98,41,0};
static const PCRE2_UCHAR s2[]={97,98,99,0};
static const PCRE2_UCHAR r2[]={0};
static const PCRE2_UCHAR n2[]={110,0};
static const PCRE2_UCHAR p3[]={40,42,77,65,82,75,58,62,0,60,41,46,46,0};
static const PCRE2_UCHAR s3[]={65,66,0};
static const PCRE2_UCHAR r3[]={0};
static const PCRE2_UCHAR n3[]={110,0};
static const PCRE2_UCHAR p4[]={40,42,77,65,82,75,58,62,0,60,41,46,46,0};
static const PCRE2_UCHAR s4[]={65,0};
static const PCRE2_UCHAR r4[]={0};
static const PCRE2_UCHAR n4[]={110,0};
static const PCRE2_UCHAR p5[]={40,42,77,65,82,75,58,62,0,60,41,46,46,0};
static const PCRE2_UCHAR s5[]={65,0};
static const PCRE2_UCHAR r5[]={0};
static const PCRE2_UCHAR n5[]={110,0};
static const PCRE2_UCHAR p6[]={40,42,77,65,82,75,58,62,0,60,41,46,40,63,67,49,41,46,0};
static const PCRE2_UCHAR s6[]={65,66,0};
static const PCRE2_UCHAR r6[]={0};
static const PCRE2_UCHAR n6[]={110,0};
static const PCRE2_UCHAR p7[]={88,0};
static const PCRE2_UCHAR s7[]={88,88,55296,0};
static const PCRE2_UCHAR r7[]={0};
static const PCRE2_UCHAR n7[]={110,0};
static const PCRE2_UCHAR p8[]={88,0};
static const PCRE2_UCHAR s8[]={88,88,55808,0};
static const PCRE2_UCHAR r8[]={0};
static const PCRE2_UCHAR n8[]={110,0};
static const PCRE2_UCHAR p9[]={88,0};
static const PCRE2_UCHAR s9[]={88,88,56320,0};
static const PCRE2_UCHAR r9[]={0};
static const PCRE2_UCHAR n9[]={110,0};
static const PCRE2_UCHAR p10[]={88,0};
static const PCRE2_UCHAR s10[]={88,88,56832,0};
static const PCRE2_UCHAR r10[]={0};
static const PCRE2_UCHAR n10[]={110,0};
static const PCRE2_UCHAR p11[]={88,0};
static const PCRE2_UCHAR s11[]={88,88,57343,0};
static const PCRE2_UCHAR r11[]={0};
static const PCRE2_UCHAR n11[]={110,0};
static const PCRE2_UCHAR p12[]={88,0};
static const PCRE2_UCHAR s12[]={88,88,55296,4660,0};
static const PCRE2_UCHAR r12[]={0};
static const PCRE2_UCHAR n12[]={110,0};
static const PCRE2_UCHAR p13[]={40,63,60,61,46,41,88,0};
static const PCRE2_UCHAR s13[]={88,88,55296,0};
static const PCRE2_UCHAR r13[]={0};
static const PCRE2_UCHAR n13[]={110,0};
static const Case cases[]={
{"UP-SUP-101",0,p0,s0,r0,n0,14,3,0,4200448,0,0,0,2,1,255,15,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0},
{"UP-SUP-102",0,p1,s1,r1,n1,11,3,0,6144,0,0,0,2,1,255,15,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0},
{"UP-SUP-103",0,p2,s2,r2,n2,11,3,0,4200448,0,0,0,2,1,255,15,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0},
{"UP-SUP-104",0,p3,s3,r3,n3,13,2,0,71680,0,0,0,2,1,255,15,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0},
{"UP-SUP-105",0,p4,s4,r4,n4,13,1,0,71680,0,32,0,2,1,255,15,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0},
{"UP-SUP-106",0,p5,s5,r5,n5,13,1,0,71680,0,0,0,2,1,255,15,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0},
{"UP-SUP-107",0,p6,s6,r6,n6,18,2,0,71680,0,0,0,2,1,255,15,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0},
{"UP-SUP-108",0,p7,s7,r7,n7,1,3,0,524288,0,0,0,2,1,255,15,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0},
{"UP-SUP-109",0,p8,s8,r8,n8,1,3,0,524288,0,0,0,2,1,255,15,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0},
{"UP-SUP-110",0,p9,s9,r9,n9,1,3,0,524288,0,0,0,2,1,255,15,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0},
{"UP-SUP-111",0,p10,s10,r10,n10,1,3,0,524288,0,0,0,2,1,255,15,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0},
{"UP-SUP-112",0,p11,s11,r11,n11,1,3,0,524288,0,0,0,2,1,255,15,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0},
{"UP-SUP-113",0,p12,s12,r12,n12,1,4,0,524288,0,0,0,2,1,255,15,128,0,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0},
{"UP-SUP-114",0,p13,s13,r13,n13,7,3,0,524288,0,0,0,2,1,255,15,128,3,{1,1,1},-1,-1,-1,-1,-1,NULL,NULL,NULL,0,SIZE_MAX,NULL,0,-1,NULL,0}
};
